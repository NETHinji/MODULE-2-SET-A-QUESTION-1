create Schema SarthakSales
Go


create table SarthakSales.VijaySales
(
SerialNumber nvarchar(50),
ProductName nvarchar(50),
BrandName nvarchar(20),
ProductType nvarchar(20),
ProductDescription nvarchar(50),
ProductPrice decimal(10,4)
)  
select * from  SarthakSales.VijaySales
create proc SarthakSales.AddProduct
(
@sNum nvarchar(50),
@pName nvarchar(50),
@bName nvarchar(50),
@pType nvarchar(20),
@pDescription nvarchar(50),
@pPrice decimal(10,4)
)
as
begin 
insert into SarthakSales.VijaySales
values(@sNum,@pName,@bName,@pType,@pDescription,@pPrice)
end

Create proc SarthakSales.Display
as
begin
select *
from SarthakSales.VijaySales
end



drop proc SarthakSales.Display