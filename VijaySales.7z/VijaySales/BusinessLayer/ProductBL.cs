﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using Entities;
using Exceptions;
using System.Data;


namespace BusinessLayer
{
    public class ProductBL
    {
        public int AddProduct(Product pobj)
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.AddProduct(pobj);
            }
            catch (ProductException)
            {
                throw;
            }
        }
        public DataTable Display()
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.Display();
            }
            catch (ProductException)
            {
                throw;
            }
        }

    }
}
