﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace VijaySalesUI
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void App_Startup(object sender, StartupEventArgs e)
        {
            Display_All_Products mainWindow = new Display_All_Products();

            mainWindow.Top = 100;

            mainWindow.Left = 400;

            mainWindow.Show();
        }
    }
}
